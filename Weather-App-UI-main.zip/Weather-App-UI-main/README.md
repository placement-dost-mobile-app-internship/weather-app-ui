# Flutter Weather App UI

A Flutter project where I have created Weather App UI.

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://docs.flutter.dev/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://docs.flutter.dev/cookbook)

For help getting started with Flutter development, view the
[online documentation](https://docs.flutter.dev/), which offers tutorials,
samples, guidance on mobile development, and a full API reference.

## Screenshots
![](https://raw.githubusercontent.com/ak-2301/Weather-App-UI/main/screenshots/weather1.png)
![](https://raw.githubusercontent.com/ak-2301/Weather-App-UI/main/screenshots/weather2.png)
![](https://raw.githubusercontent.com/ak-2301/Weather-App-UI/main/screenshots/weather3.png)
![](https://raw.githubusercontent.com/ak-2301/Weather-App-UI/main/screenshots/weather4.png)
